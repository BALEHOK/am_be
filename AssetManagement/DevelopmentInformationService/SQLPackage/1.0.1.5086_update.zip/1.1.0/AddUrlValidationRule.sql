BEGIN TRANSACTION T1;
DECLARE @vaId bigint;
SELECT @vaId = MAX(ValidationOperatorUid) FROM ValidationOperator;
SET @vaId = @vaId + 1;

SET IDENTITY_INSERT ValidationOperator ON;
INSERT INTO ValidationOperator(ValidationOperatorUid, Name, ClassName, Unary)
VALUES (@vaId, 'IsUrl', 'Operators.ValidationOperatorIsUrl', 0);
SET IDENTITY_INSERT ValidationOperator OFF;

INSERT INTO [ValidationList] (Name, ValidationOperatorUid)
VALUES('Url', @vaId);

INSERT INTO [ValidationList] (Name, ValidationOperatorUid)
VALUES('googleMaps', @vaId);
COMMIT TRANSACTION T1;