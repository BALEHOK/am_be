-- Put the SQL queries here delimiting by double line break.
CREATE TRIGGER [dbo].[tr_SetADynEntityFaqZID]
ON [dbo].[ADynEntityFaqZ]  AFTER INSERT, UPDATE 
AS 
BEGIN 
	SET NOCOUNT ON;
	UPDATE [ADynEntityFaqZ] 
	SET DynEntityId = DynEntityUid 
	WHERE DynEntityId = 0
	AND DynEntityUid IN (SELECT DynEntityUid FROM Inserted); 
END;
