USE [assetmanager]
GO

/****** Object:  Table [dbo].[Reservation]    Script Date: 11/10/2010 12:15:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Reservation]') AND type in (N'U'))
DROP TABLE [dbo].[Reservation]
GO

USE [assetmanager]
GO

/****** Object:  Table [dbo].[Reservation]    Script Date: 11/10/2010 12:36:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Reservation](
	[ReservationUID] [bigint] IDENTITY(1,1) NOT NULL,
	[DynEntityUID] [bigint] NOT NULL,
	[DynEntityConfigUID] [bigint] NOT NULL,
	[UpdateUserId] [bigint] NOT NULL,
	[Borrower] [bigint] NOT NULL,
	[StartDate] [datetime] NOT NULL,
	[EndDate] [datetime] NOT NULL,
	[ReservationDate] [datetime] NOT NULL,
	[UpdateDate] [datetime] NOT NULL,
	[Reason] [nvarchar](1000) NULL,
	[Remarks] [nvarchar](1000) NULL,
	[IsColsed] [bit] NOT NULL,
	[IsDamaged] [bit] NOT NULL,
 CONSTRAINT [PK_Reservation2] PRIMARY KEY CLUSTERED 
(
	[ReservationUID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Reservation] ADD  CONSTRAINT [DF_Reservation_UpdateDate]  DEFAULT (getdate()) FOR [UpdateDate]
GO

ALTER TABLE [dbo].[Reservation] ADD  CONSTRAINT [DF_Reservation2_IsColsed]  DEFAULT ((0)) FOR [IsColsed]
GO

ALTER TABLE [dbo].[Reservation] ADD  CONSTRAINT [DF_Reservation2_IsDamaged]  DEFAULT ((0)) FOR [IsDamaged]
GO


