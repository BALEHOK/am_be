BEGIN TRANSACTION T1;
-- Get the latest Asset Type Id
DECLARE @atId bigint;
SELECT @atId = MAX(DynEntityConfigUid) FROM DynEntityConfig;
SET @atId = @atId + 1;
-- Create the FAQ Asset Type
SET IDENTITY_INSERT [DynEntityConfig] ON;
INSERT INTO [DynEntityConfig] ([DynEntityConfigUid] ,[DynEntityConfigId] ,[Revision] ,[ActiveVersion] ,[Name] ,[DBTableName] ,[TypeId] ,[ContextId] ,[ScreenlayoutId] ,[Active] ,[IsSearchable] ,[IsIndexed] ,[IsContextIndexed] ,[Comment] ,[UpdateUserId] ,[UpdateDate] ,[MeasureUnitId] ,[IsInStock] ,[IsUnpublished])
VALUES (@atId, @atId, 1,1, 'Faq', 'ADynEntityFaqZ', 1, 13, 1,1,1,1,1, 'FAQ items', 1, GETDATE(), 0,0,0);   
SET IDENTITY_INSERT [DynEntityConfig] OFF;
-- GET THE LATEST Attribute Uid
DECLARE @attUid bigint;
SELECT @attUid = MAX(DynEntityAttribConfigUid) FROM DynEntityAttribConfig;
-- CREATE Asset Type Attributes
SET IDENTITY_INSERT DynEntityAttribConfig ON;
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+1,	@atId,	@attUid+1,	'DynEntityUid',			NULL,	31,	NULL,	'DynEntityUid',			NULL,	0,	0,	1,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),  '',					NULL,	2,	1,	0,	NULL,	1,	NULL,	NULL,	NULL,	0,	0,	0,	0,	0,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+2,	@atId,	@attUid+2,	'DynEntityId',			NULL,	31,	NULL,	'DynEntityId',			NULL,	0,	0,	1,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'',					NULL,	2,	1,	0,	NULL,	1,	NULL,	NULL,	NULL,	0,	0,	0,	0,	0,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+3,	@atId,	@attUid+3,	'ActiveVersion',		NULL,	34,	NULL,	'ActiveVersion',		NULL,	0,	0,	1,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'',					NULL,	2,	1,	0,	NULL,	1,	NULL,	NULL,	NULL,	0,	0,	0,	0,	0,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+4,	@atId,	@attUid+4,	'DynEntityConfigUid',	NULL,	31,	NULL,	'DynEntityConfigUid',	NULL,	0,	0,	1,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'',					NULL,	2,	1,	0,	NULL,	1,	NULL,	NULL,	NULL,	0,	0,	0,	0,	0,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+5,	@atId,	@attUid+5,	'Name',					NULL,	35,	NULL,	'Name',					NULL,	0,	0,	1,	1,	NULL,	1,	1,	0,		1,	1,	GETDATE(),	'Name',				NULL,	2,	1,	0,	NULL,	1,	NULL,	NULL,	NULL,	0,	1,	1,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+6,	@atId,	@attUid+6,	'Revision',				NULL,	41,	NULL,	'Revision',				NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Revision',			NULL,	2,	1,	0,	NULL,	1,	NULL,	NULL,	NULL,	0,	0,	1,	0,	0,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+7,	@atId,	@attUid+7,	'Barcode',				NULL,	51,	NULL,	'Barcode',				NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Barcode',			NULL,	2,	1,	0,	NULL,	1,	NULL,	NULL,	NULL,	0,	0,	0,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+8,	@atId,	@attUid+8,	'Location',				NULL,	38,	NULL,	'LocationId',			NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Location',			NULL,	2,	1,	0,	NULL,	1,	2,		31,		NULL,	0,	0,	0,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+9,	@atId,	@attUid+9,	'Base Location',		NULL,	38,	NULL,	'BaseLocationId',		NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Base Location',	NULL,	2,	1,	0,	NULL,	1,	2,		31,		NULL,	0,	0,	0,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+10,	@atId,	@attUid+10,	'Next Location',		NULL,	38,	NULL,	'NextLocationId',		NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Next Location',	NULL,	2,	1,	0,	NULL,	1,	2,		31,		NULL,	0,	0,	0,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+11,	@atId,	@attUid+11,	'Department',			NULL,	38,	NULL,	'DepartmentId',			NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Department',		NULL,	2,	1,	0,	NULL,	1,	3,		49,		NULL,	0,	0,	0,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+12,	@atId,	@attUid+12,	'User',					NULL,	38,	NULL,	'UserId',				NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'User',				NULL,	2,	1,	0,	NULL,	1,	1,		5,		NULL,	0,	0,	0,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+13,	@atId,	@attUid+13,	'Owner',				NULL,	38,	NULL,	'OwnerId',				NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Owner',			NULL,	2,	1,	0,	NULL,	1,	1,		5,		NULL,	0,	0,	0,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+14,	@atId,	@attUid+14,	'Update User',			NULL,	38,	NULL,	'UpdateUserId',			NULL,	0,	0,	1,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Update User',		NULL,	2,	1,	0,	NULL,	1,	1,		5,		NULL,	0,	0,	1,	0,	0,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+15,	@atId,	@attUid+15,	'Update Date',			NULL,	40,	NULL,	'UpdateDate',			NULL,	0,	0,	1,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Update Date',		NULL,	2,	1,	0,	NULL,	1,	NULL,	NULL,	NULL,	0,	0,	1,	0,	0,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+16,	@atId,	@attUid+16,	'Stock Count',			NULL,	49,	NULL,	'StockCount',			NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Stock Count',		NULL,	2,	1,	0,	NULL,	1,	NULL,	NULL,	NULL,	0,	0,	0,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+17,	@atId,	@attUid+17,	'Stock Price',			NULL,	49,	NULL,	'StockPrice',			NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Stock Price',		NULL,	2,	1,	0,	NULL,	1,	NULL,	NULL,	NULL,	0,	0,	0,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+18,	@atId,	@attUid+18,	'Document',				NULL,	53,	NULL,	'DocumentId',			NULL,	0,	0,	0,	0,	NULL,	0,	0,	0,		0,	1,	GETDATE(),	'Document',			NULL,	2,	1,	0,	NULL,	1,	4,		67,		NULL,	0,	0,	0,	0,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+19,	@atId,	@attUid+19,	'Question',				NULL,	35,	NULL,	'Question',				NULL,	0,	0,	1,	1,	NULL,	0,	1,	NULL,	1,	1,	GETDATE(),	'Question',			NULL,	2,	1,	0, 	NULL,	1,	0,		0,		NULL,	1,	1,	1,	1,	1,	NULL);
INSERT INTO DynEntityAttribConfig ([DynEntityAttribConfigUid] ,[DynEntityConfigUid] ,[DynEntityAttribConfigId] ,[Name] ,[NameTranslationId] ,[DataTypeUid] ,[DynListUid] ,[DBTableFieldname] ,[ContextId] ,[IsDynListValue] ,[IsFinancialInfo] ,[IsRequired] ,[IsKeyword] ,[Format] ,[IsFullTextInidex] ,[DisplayOnResultList] ,[DisplayOrderResultList] ,[DisplayOnExtResultList] ,[UpdateUserId] ,[UpdateDate] ,[Label] ,[LabelTranslationId] ,[Revision] ,[ActiveVersion] ,[DisplayOrderExtResultList] ,[Comment] ,[Active] ,[RelatedAssetTypeID] ,[RelatedAssetTypeAttributeID] ,[ValidationExpr] ,[IsDescription] ,[IsShownInGrid] ,[IsShownOnPanel] ,[AllowEditConfig] ,[AllowEditValue] ,[ValidationMessage])
VALUES (@attUid+20,	@atId,	@attUid+20,	'Answer',				NULL,	35,	NULL,	'Answer',				NULL,	0,	0,	1,	1,	NULL,	0,	1,	NULL,	1,	1,	GETDATE(),	'Answer',			NULL,	2,	1,	0,	NULL,	1,	0,		0,		NULL,	1,	1,	1,	1,	1,	NULL);
SET IDENTITY_INSERT DynEntityAttribConfig OFF;

-- CREATE NEW PREDEFINED ASSETTYPE RECORD
INSERT INTO [PredefinedAttributes] ([Name],[DynEntityConfigID],[DynEntityAttribConfigID])
VALUES('Faq', @atId, @attUid+5);

-- CREATE PANELS
DECLARE @panelUid bigint;
SELECT @panelUid = MAX(AttributePanelUid) FROM AttributePanel;
SET @panelUid = @panelUid + 1;
SET IDENTITY_INSERT AttributePanel ON;
INSERT INTO AttributePanel([AttributePanelUid],[AttributePanelId],[DynEntityConfigUId],
[Name],[NameTranslationId],[DisplayOrder],[Description],[HeaderLabel],[HeaderLabelTranslationId],
[UpdateUserId],[UpdateDate])
VALUES(@panelUid, @panelUid, @atId, 'General',NULL,0,'','',NULL,1,GETDATE());
INSERT INTO AttributePanel([AttributePanelUid],[AttributePanelId],[DynEntityConfigUId],
[Name],[NameTranslationId],[DisplayOrder],[Description],[HeaderLabel],[HeaderLabelTranslationId],
[UpdateUserId],[UpdateDate])
VALUES(@panelUid+1, @panelUid+1, @atId, 'Content',NULL,1,'','',NULL,1,GETDATE());
SET IDENTITY_INSERT AttributePanel OFF;

-- ADD Attributes TO PANELS
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+1, 0, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+2, 1, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+3, 2, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+4, 3, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+5, 4, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+6, 5, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+7, 6, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+8, 7, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+9, 8, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+10, 9, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+11, 10, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+12, 11, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+13, 12, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+14, 13, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+15, 14, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+16, 15, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+17, 16, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid, @attUid+18, 17, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid+1, @attUid+19, 0, 1, GETDATE());
INSERT INTO[AttributePanelAttribute] ([AttributePanelUid],[DynEntityAttribConfigUId] ,[DisplayOrder] ,[UpdateUserId] ,[UpdateDate])
VALUES(@panelUid+1, @attUid+20, 0, 1, GETDATE());

-- CREATE FAQ Assets TABLE
CREATE TABLE [dbo].[ADynEntityFaqZ](
	[DynEntityUid] [bigint] IDENTITY(1,1) NOT NULL,
	[DynEntityId] [bigint] NOT NULL,
	[ActiveVersion] [bit] NOT NULL,
	[DynEntityConfigUid] [bigint] NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[Revision] [int] NULL,
	[Barcode] [nvarchar](50) NOT NULL,
	[LocationId] [bigint] NOT NULL,
	[BaseLocationId] [bigint] NOT NULL,
	[NextLocationId] [bigint] NULL,
	[DepartmentId] [bigint] NOT NULL,
	[UserId] [bigint] NOT NULL,
	[OwnerId] [bigint] NOT NULL,
	[UpdateUserId] [bigint] NOT NULL,
	[UpdateDate] [datetime] NOT NULL,
	[StockCount] [float] NULL,
	[StockPrice] [float] NULL,
	[DocumentId] [bigint] NULL,
	[Question] [nvarchar](255) NOT NULL,
	[Answer] [nvarchar](255) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[DynEntityUid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ((0)) FOR [DynEntityId]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ((0)) FOR [ActiveVersion]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ((0)) FOR [DynEntityConfigUid]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [Name]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [Revision]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [Barcode]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [LocationId]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [BaseLocationId]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [NextLocationId]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [DepartmentId]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [UserId]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [OwnerId]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [UpdateUserId]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT (getdate()) FOR [UpdateDate]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [StockCount]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [StockPrice]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [DocumentId]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [Question]
GO

ALTER TABLE [dbo].[ADynEntityFaqZ] ADD  DEFAULT ('') FOR [Answer]
GO
 
CREATE UNIQUE NONCLUSTERED INDEX [Id_Revision] ON [dbo].[ADynEntityFaqZ]
( [DynEntityId] ASC, [Revision] ASC );

            
CREATE NONCLUSTERED INDEX [Id_ActiveVersion] ON [dbo].[ADynEntityFaqZ]
( [DynEntityId] ASC, [ActiveVersion] ASC ); 
COMMIT TRANSACTION T1;