BEGIN TRANSACTION T1;
DECLARE @dtId bigint;
SELECT @dtId = MAX(DataTypeUid) FROM DataType;

SET IDENTITY_INSERT DataType ON;
INSERT INTO DataType ([DataTypeUid] ,[Name] ,[NameTranslationId] ,[DBDataType] ,[FrameworkDataType] ,[Comment] ,[UpdateUserId] ,[UpdateDate] ,[StringSize] ,[DefaultValueID] ,[ValidationExpr] ,[IsInternal] ,[IsEditable] ,[ValidationMessage])
VALUES (@dtId+1, 'url', 'url', 'varchar', 'string', NULL , 1, GETDATE(), 1000, NULL, '@Url', 0, 1, '{0} is not valid Url.');

INSERT INTO DataType ([DataTypeUid] ,[Name] ,[NameTranslationId] ,[DBDataType] ,[FrameworkDataType] ,[Comment] ,[UpdateUserId] ,[UpdateDate] ,[StringSize] ,[DefaultValueID] ,[ValidationExpr] ,[IsInternal] ,[IsEditable] ,[ValidationMessage])
VALUES (@dtId+2, 'text', 'text', 'text', 'string', NULL , 1, GETDATE(), NULL, NULL, NULL, 0, 1, NULL);

INSERT INTO DataType ([DataTypeUid] ,[Name] ,[NameTranslationId] ,[DBDataType] ,[FrameworkDataType] ,[Comment] ,[UpdateUserId] ,[UpdateDate] ,[StringSize] ,[DefaultValueID] ,[ValidationExpr] ,[IsInternal] ,[IsEditable] ,[ValidationMessage])
VALUES (@dtId+3, 'image', 'image', 'varchar', 'string', NULL , 1, GETDATE(), 1000, NULL, NULL, 0, 1, NULL);

INSERT INTO DataType ([DataTypeUid] ,[Name] ,[NameTranslationId] ,[DBDataType] ,[FrameworkDataType] ,[Comment] ,[UpdateUserId] ,[UpdateDate] ,[StringSize] ,[DefaultValueID] ,[ValidationExpr] ,[IsInternal] ,[IsEditable] ,[ValidationMessage])
VALUES (@dtId+3, 'googleMaps', 'Google Maps Location', 'nvarchar', 'string', NULL , 1, GETDATE(), 1000, NULL, NULL, 0, 1, NULL);

SET IDENTITY_INSERT DataType OFF;
COMMIT TRANSACTION T1;