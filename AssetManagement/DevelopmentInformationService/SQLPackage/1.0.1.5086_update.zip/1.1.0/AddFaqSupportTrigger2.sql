CREATE TRIGGER [dbo].[tr_SetADynEntityFaqZRevisionNumber] 
ON [dbo].[ADynEntityFaqZ] INSTEAD OF INSERT 
AS 
BEGIN 
	SET NOCOUNT ON;
	DECLARE @id bigint;
	DECLARE @rev bigint;	
	SET @rev = 0;	
	SELECT @id = [DynEntityId] 
	FROM Inserted;	
	SELECT @rev = MAX([Revision])
	FROM [ADynEntityFaqZ] 
	WHERE [DynEntityId] = @id;	
	SELECT * INTO #temp 
	FROM Inserted;	
	ALTER TABLE #temp
	DROP COLUMN [DynEntityUid];	
	UPDATE #temp
	SET [Revision] = ISNULL(@rev, 0) + 1;	
	INSERT INTO [ADynEntityFaqZ] SELECT * FROM #temp;	
	DROP TABLE #temp;
END;